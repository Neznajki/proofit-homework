package data.object;

public class PolicyObject {
    public String name;
    public PolicySubObject[] policySubObjects = null;
}
