package data.object;

public class PolicySubObject {
    public String name;
    public double sumInsured;
    public String riskType;
}
