package data.object;

public class IncomingRequest {
    public String policyNumber;
    public String policyStatus;
    public PolicyObject[] policyObjects;
    public double premium;
}
