package helper;

public class Debug {
    /**
     * as this is api e.printStackTrace should be replaced with some debugging tool, as this is test task I will just output it
     * @param e exception caught by EntryPoint (cases when response could not be calculated for single IncomingRequest single exception)
     */
    public void handleException(Exception e)
    {
        //e.printStackTrace();//maybe ??
    }
}
